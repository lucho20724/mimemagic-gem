## Rails 4.2.4 (August 24, 2015) ##

*   Include I18n.locale into job serialization/deserialization and use it around
    `perform`.

    Fixes #20799.

    *Johannes Opper*

## Rails 4.2.3 (June 25, 2015) ##

*   `assert_enqueued_jobs` and `assert_performed_jobs` in block form use the
    given number as expected value. This makes the error message much easier to
    understand.

    *y-yagi*


## Rails 4.2.2 (June 16, 2015) ##

* No Changes *


## Rails 4.2.1 (March 19, 2015) ##

*   Allow keyword arguments to be used with Active Job.

    Fixes #18741.

    *Sean Griffin*


## Rails 4.2.0 (December 20, 2014) ##

*  Started project.
